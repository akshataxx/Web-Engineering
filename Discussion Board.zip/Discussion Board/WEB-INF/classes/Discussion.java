/*
 * Akshata Dhuraji - c3309266
 * Assignment 1 SENG2050
 * Discussion class - Code to switch between page A and Page B
 */
// Import required java libraries
import java.io.*;
import java.lang.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import javax.servlet.annotation.WebServlet;

@WebServlet(urlPatterns = {"/Discussion"})
public class Discussion extends HttpServlet {
	//variable declaration
	private static TreeMap<String, Message> msglist = new TreeMap<String, Message>();//used Treemap so that messages are sorted
	private String heading, title, fname, lname, time, type, content, message,mnum, mstype;
	private static int count = 1;
	
//Page B code to capture the discussion details.	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		String mtype=null;
		String rtype=null;
		String comparemsg = null;
		
		PrintWriter out = response.getWriter();
		ServletContext context=getServletContext();  
				
		if (request.getParameter("submit") != null) {//check if submit button is clicked
			System.out.println("Submit Button type " );//--Debug code
			type="M" + count;
			context.setAttribute("type",type);  
			count++;
		}
		else if (request.getParameter("msgtype") != null) {//check if reply is clicked
			int counter=0;
			int replycount=0;
			mnum = request.getParameter("msgtype");
			System.out.println("Get Reply clicked " + mnum);//--Debug code
			
			if (mnum.length() <= 4){
				mtype = mnum.substring(0,2);
				System.out.println("From Get Reply - Message number " + mtype);//--Debug code
			}
			else{
				rtype = mnum.substring(0,4);//--Debug code
				System.out.println("From Get Reply - Reply Message number " + rtype);//--Debug code
			}	
			
			String temp="";
			for (Message messages : msglist.values()) {//get the count of message  in the list
				comparemsg=messages.getType();
				if(mnum.length()<=4){
					if (mtype.equals(comparemsg.substring(0,2))) {//get the count of message replies in the list
						counter++;
					}
				}
				if (mnum.length()==4){
					temp=mnum+"R0";
					if(temp.equals(comparemsg)){
						replycount++;
					}
				}
			}
			System.out.println("Message " + mtype +" exist "+ counter);//--Debug code
			System.out.println("Reply to message " + mtype +" exist "+ replycount);//--Debug code
			
			if (counter >= 10){//check if the messages are more than 10 then show a message
				message = "Sorry! we allow only upto 10 replies.";
				System.out.println(message);
				response.sendRedirect("Discussion?message=success");
			}
			else if(mnum.contains("R") && replycount ==0){//case message has no previous reply of replies
				type=mnum+"R0";
				System.out.println("From get: message has previous reply" + type);//--Debug code
				context.setAttribute("type",type);
			}
			else if(mnum.contains("R") &&  replycount > 0){//case message has previous reply of replies
				type = mnum + "R"+ replycount;
				System.out.println("From get: reply of reply" + type);//--Debug code
				context.setAttribute("type",type);	
			}
			else if(!mnum.contains("R") && counter>1){//case core message clicked and message has previous replies	
				counter = --counter;
				type = mnum+"R"+counter;
				System.out.println("From get: Core message clicked and message has previous reply" + type);//--Debug code
				context.setAttribute("type",type);
			}	
			else if(!mnum.contains("R") && counter==1){//case message has no previous replies
				type = mnum+"R0";
				System.out.println("From get: message with no previous reply" + type);//--Debug code
				context.setAttribute("type",type);
			}
					
		}		
		//Page B form to capture the discussion details
		String discussion = "<!DOCTYPE HTML>\n";
			discussion += "<html>\n"+ 
							"<head>\n"+ 
								"<meta charset='utf-8'>\n"+
								"<meta name ='description' content = 'discussion form'>"+
								"<link rel= 'stylesheet' type='text/css' href='css/style.css' media= 'screen' />\n"+
								"<script src='discussion.js' type='text/javascript'></script>\n"+
								"<title>Discussion Details</title>\n" + 
							"</head>\n" + "<body>\n"+
							"<form name='discussion' action='Discussion' onsubmit=\"return validateForm()\" method='post'>"+
								"<h2>"+"Discussion Details"+"</h2>"+
								"<hr>\n"+								
								"<ul class= 'form-style-1'>"+
								"<li><label>"+
									"Heading*:</label><input type='text' name='heading' class='mytext'/></li><br />\n"+
								"<li><label>"+
									"Title of message*:</label><input type='text' name='title' class='mytext'/></li><br />\n"+
								"<li><label>"+
									"UserName</label><input type='text' name='userfname' class='field-divided' placeholder='First'/><input type = 'text' name='userlname' class ='field-divided' placeholder= 'Last'/></li><br />\n"+	
								"<li><label>"+
									"Content:</label><textarea name='content' id='content' class='field-long field-textarea' autocorrect='on'></textarea></li><br />\n"+
								"<input type='submit' value='Post' />\n"+
								"</ul>"+
								"<input type='hidden' name='type' >"+

							"</form>\n"+ "</body>\n"+ 
							"<footer>"+ 
								"&copy;"+
								"All rights reserved , Copyright University of NewCastle-Callaghan 2022"+
								"<br/> Akshata Dhuraji, SENG2050, University of NewCastle,"+
								"<u>Email:c3309266@uon.edu.au</u>" +
							"</footer>\n"+ "</html>\n";
			try{
					out.println(discussion);
				}finally{
					out.close(); //always close the output writer
				}	
	}
	//Page A form to display messages
	public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();		
		ServletContext context=getServletContext(); 			
		
		Message msgs=new Message();//Create a object of message class to read and store the form values
		msgs.setHeading(request.getParameter("heading"));
		msgs.setTitle(request.getParameter("title"));
		msgs.setUserlname(request.getParameter("userlname"));
		msgs.setContent(request.getParameter("content"));
		msgs.setTime(currentTime());
		
		fname=request.getParameter("userfname");
		lname=request.getParameter("userlname");
		if(fname==null || fname=="" || fname.length()==0){
			fname="Anonymous";
		}
		msgs.setUserfname(fname);
		

		
		String msgtype = (String)context.getAttribute("type");
		System.out.println("message type " + msgtype); //--Debug code
		
		if(msgtype == null){
			msgtype="M0";
		}
		msgs.setType(msgtype);
		
		msglist.put(msgtype,msgs);//add the form values in the hashmap
		System.out.println("post msglist addition" + msglist);//--Debug code
		
		
		String postmessage; //page A html code
		postmessage = "<!DOCTYPE html>\n <html>\n"+ "<head>\n"+ 
					"<title>Discussion Board</title>\n"+
					"<link rel= 'icon' type='images/discussion.png' href='/images/discussion.png'>\n"+
					"<meta charset='utf-8'>\n"+
					"<meta name='viewport' content='width=device-width, initial-scale=1.0'>\n"+
					"<link rel= 'stylesheet' type='text/css' href='css/style.css' media= 'screen' />\n"+
				    "</head>\n"+ "<body>\n"+
					"<form name='Board' action='Discussion' method='get' >\n"+
						"<h2>"+"Discussion Board"+"</h2>"+
						"<hr>\n"+
						"<input type='submit' name= 'submit' value='Post Message' />\n";
					if(message != null){
						message = request.getParameter("message");
						postmessage= postmessage + "<p>" + message + "</p>\n";
					}
						
					for (Message listofmsg : msglist.values()) { //function to print the discussion list in the order as specified in the assig
						mstype = listofmsg.getType();
						if(!mstype.contains("R") ){ //print core messages
							postmessage = postmessage+	"<ul class ='mylist'>\n"+
								"<li class='by1'>" + listofmsg.getHeading()+ "</li><br />"+
								"<li class='by2'>" + listofmsg.getTitle()+ "</li><br />"+
								"<li class='bich'>" + listofmsg.getContent()+ "</li><br />"+
								"<li class='dy1'>"+ listofmsg.getUserfname()+" "+ listofmsg.getUserlname()+"</li><br />"+
								"<li class='dy2'>" + listofmsg.getTime()+ "</li><br />\n"+
							"</ul>"+
							"<a href='Discussion?msgtype="+listofmsg.getType()+"'>Reply</a>\n";
						}
						else if(mstype.contains("R") && (mstype.length()<=4)){//print core messages with replies
							postmessage = postmessage+	"<ul class ='msgreplylist'>\n"+
								"<li class='le1'>" + listofmsg.getHeading()+ "</li><br />"+
								"<li class='le2'>" + listofmsg.getTitle()+ "</li><br />"+
								"<li class='mid'>" + listofmsg.getContent()+ "</li><br />"+
								"<li class='ri1'>"+ listofmsg.getUserfname()+" "+ listofmsg.getUserlname()+"</li><br />"+
								"<li class='ri2'>" + listofmsg.getTime()+ "</li><br />\n"+
							"</ul>"+
							"<a href='Discussion?msgtype="+listofmsg.getType()+"'>Reply</a>\n";
						}
						else if(mstype.contains("R") && (mstype.length()>4)){	//print reply of reply
							postmessage = postmessage +	"<ul class ='rplyreplylist'>\n"+
								"<li class='by111'>" + listofmsg.getHeading()+ "</li><br />"+
								"<li class='by211'>" + listofmsg.getTitle()+ "</li><br />"+
								"<li class='bich11'>" + listofmsg.getContent()+ "</li><br />"+
								"<li class='dy111'>"+ listofmsg.getUserfname()+" "+ listofmsg.getUserlname()+"</li><br />"+
								"<li class='dy211'>" + listofmsg.getTime()+ "</li><br />\n"+
							"</ul>"+
						"<a href='Discussion?msgtype="+listofmsg.getType()+"'>Reply</a>\n";
						}
					}
			postmessage= postmessage +	"</form>\n"+ "</body>\n"+ "<footer>"+ "&copy;"+
								"All rights reserved , Copyright University of NewCastle-Callaghan 2022"+
								"<br/> Akshata Dhuraji, SENG2050, University of NewCastle,"+
								"<u>Email:c3309266@uon.edu.au</u>" +
								"</footer>\n"+ "</html>\n";
			try{
				out.println(postmessage);
			}finally{
				out.close(); //always close the output writer
			}
	}				
						
	
	//time function
	private String currentTime(){
		Calendar calendar = new GregorianCalendar();
		String am_pm;
		int date = calendar.get(Calendar.DATE);
		int month = calendar.get(Calendar.MONTH);
		int yr = calendar.get(Calendar.YEAR);
		int hour = calendar.get(Calendar.HOUR);
		int minute = calendar.get(Calendar.MINUTE);
		int second = calendar.get(Calendar.SECOND);
         
		if(calendar.get(Calendar.AM_PM) == 0)
			am_pm = "AM";
		else
			am_pm = "PM";
 
		String CT = date+"/"+month+"/"+yr+" "+hour+":"+ minute +":"+ second +" "+ am_pm;
		return CT;
	}	
}