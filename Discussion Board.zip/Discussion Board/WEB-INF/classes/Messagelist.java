/*
 * Akshata Dhuraji - c3309266
 * Assignment 1 SENG2050
 * Messagelist class - Home page of discussion list
 */

// Import required java libraries
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import javax.servlet.annotation.WebServlet;

@WebServlet(urlPatterns = {"/Messagelist"})

// Extend HttpServlet class
public class Messagelist extends HttpServlet {
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Set response content type
		response.setContentType("text/html");

		PrintWriter out = response.getWriter();
		int counter=0;		
		String discussionlist; //page A html code
		discussionlist = "<!DOCTYPE html>\n <html>\n"+ "<head>\n"+ 
					"<title>Welcome to Discussion Board</title>\n"+
					"<link rel= 'icon' type='images/discussion.png' href='/images/discussion.png'>\n"+
					"<meta charset='utf-8'>\n"+
					"<link rel= 'stylesheet' type='text/css' href='css/style.css' media= 'screen' />\n"+
				    "</head>\n"+ "<body>\n"+
					"<form name='Board' action='Discussion' >\n"+
						"<h2>"+"Discussion Board"+"</h2>\n"+
						"<hr>\n"+
						"<input type='submit' value='Post Message' />\n"+
					"</form>\n"+ "<br />\n"+ "<br />\n"+"<br />\n"+"<br />\n"+"<br />\n"+"<br />\n"+"<br />\n"+"<br />\n"+"<br />\n"+
					"<br />\n"+"<br />\n"+"<br />\n"+"<br />\n"+"<br />\n"+
					"</body>\n"+ 
					"<footer>"+ 
						"&copy;"+
						"All rights reserved , Copyright University of NewCastle-Callaghan 2022"+
						"<br/> Akshata Dhuraji, SENG2050, University of NewCastle,"+
						"<u>Email:c3309266@uon.edu.au</u>" +
					"</footer>\n"+ "</html>\n";
				try{
					out.println(discussionlist);
				}finally{
					out.close(); //always close the output writer
				}	
	}
	

	
}
					
						