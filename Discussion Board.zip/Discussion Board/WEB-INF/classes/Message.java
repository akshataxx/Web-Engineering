/*
 * Akshata Dhuraji - c3309266
 * Assignment 1 SENG2050
 * Message class - base structure for message composition
 */
public class Message implements java.io.Serializable{
	//variable declaration
    private String heading;
	private String title;
	private String userfname;
	private String userlname;
    private String time;
	private String type;
	private String content;
	
	//getter and setter function
	public String getHeading(){
		return heading;
	}
	public void setHeading(String heading){
		this.heading = heading;
	}
	public String getTitle(){
		return title;
	}
	public void setTitle(String title){
		this.title = title;
	}
	public String getUserfname(){
		return userfname;
	}
	public void setUserfname(String userfname){
		this.userfname = userfname;
	}
	public String getUserlname(){
		return userlname;
	}
	public void setUserlname(String userlname){
		this.userlname = userlname;
	}
	
	public String getTime(){
		return time;
	}
	public void setTime(String time){
		this.time = time;
	}
	
	public void setContent(String content){
		this.content = content;
	}
	public String getContent(){
		return content;
	}
	public void setType(String type){
		this.type = type;
	}
	public String getType(){
		return type;
	}
}