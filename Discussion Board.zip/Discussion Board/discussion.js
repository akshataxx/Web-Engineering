/*
 * Akshata Dhuraji - c3309266
 * Assignment 1 SENG2050
 * Javascript function - validation checks of discussion form
 */

function validateForm(){	//Javascript to validate form inputs
	var alertmsg = "Form has following errors\n";
	var valid = true;
	var title = document.forms["discussion"]["title"].value;
	var content = document.getElementById("content").value;
	var len = content.length;
	
	if (title==null||title==""||title.length==0){	//If Title is left empty
		alertmsg += "Title is required\n";			//add to warning messages
		valid = false;
	}
	if (content == null||content==""){
		alertmsg += "Content can't be blank, it should be less than 50 characters and more than 5 characters\n";//add to warning messages
		valid = false;
	}
	else if(len < 5 && len > 50){
		alertmsg += "Content can't be blank, it should be less than 50 characters and more than 5 characters\n";//add to warning messages
		valid = false;
	}	
	if(valid == false){
         alert(alertmsg);
         return false;
    }
	return true;
}
	
	