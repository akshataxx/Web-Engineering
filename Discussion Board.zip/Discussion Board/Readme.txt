Discussion board program has 3 classes:
1) Message class - describes message structure, holds variables and getter setter functions
2) Messagelist - home page, user lands on to this page for posting discussions
3) Discussion class - holds the:
	a) discussion form structure-PageB and validation checks callout to the javascript function
	b)discussion list-PageA with formatting as asked in the assignment